<?php
//Importa la librería genérica para bases de datos y la instancia
require_once("../../persiste/BD.php");
$BaseDatos = new basedatos();

//Carga codigo y nombre de los colores
$Busca = "";
if (isset($_POST['ProgramasBusca'])) $Busca = $_POST['ProgramasBusca'];
echo json_encode($BaseDatos->ComboBoxDinamico("programas", "codigo", "nombre", $Busca));
exit();