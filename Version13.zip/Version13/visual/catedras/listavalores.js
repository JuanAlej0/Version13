	$(document).ready(function(){
		$("#periodo").select2({
			ajax: {
				url: "../../logica/catedras/cboPeriodo.php",
				type: "post",
				dataType: "json",
				delay: 100,
				data: function (params){
					return {
						PeriodosBusca: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				},
				cache: true
			}
		}),
		$("#modalidad").select2({
			ajax: {
				url: "../../logica/catedras/cboModalidad.php",
				type: "post",
				dataType: "json",
				delay: 100,
				data: function (params){
					return {
						ModalidadesBusca: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				},
				cache: true
			}
		}),
		$("#programa").select2({
			ajax: {
				url: "../../logica/catedras/cboPrograma.php",
				type: "post",
				dataType: "json",
				delay: 100,
				data: function (params){
					return {
						ProgramasBusca: params.term
					};
				},
				processResults: function (response) {
					return {
						results: response
					};
				},
				cache: true
			}
		})
	});
